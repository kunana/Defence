﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class vol : MonoBehaviour {

    public Slider Main = null;
	// Use this for initialization
	void Start () {
        
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    private void volaa()
    {   
        
            var audio = gameObject.GetComponent<AudioListener>();
        var vol = AudioListener.volume;
        Main.value = vol;
    }

}
