﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class ResultUI : MonoBehaviour {

    private ResultUI _instance = null;
    public ResultUI instance
    {
        get
        {
            if(_instance == null )
            {
                _instance = new ResultUI();
            }
            return _instance;
        }
    }
	// Use this for initialization
	void Start () {
        this.gameObject.SetActive(false);	
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    
    private void CallGameOver()
    {
        this.gameObject.SetActive(true);
    }
    public void ChangeToPaly()
    {   
        SceneManager.LoadScene("Game");
    }
    public void ChangeToStart()
    {
        SceneManager.LoadScene("Start");
    }
}
