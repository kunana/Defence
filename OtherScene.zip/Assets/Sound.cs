﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class Sound : MonoBehaviour {
    
    private bool volumeBtn_On = false;
    public float vol = 0;
    
	// Use this for initialization
	void Start () {
        GameObject slider = GameObject.FindGameObjectWithTag("Slider");
        slider.SetActive(false);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
    public void Mute()
    {

    }
    public void VoulmeSlider()
    {
        if(volumeBtn_On == true)
        {
            vol = AudioListener.volume = 1.0f;
        }
    }
    public void OnMouseUp()
    {
        volumeBtn_On = true;

        var slider = GameObject.FindGameObjectWithTag("Slider");
        slider.SetActive(true);


    }
    
}
