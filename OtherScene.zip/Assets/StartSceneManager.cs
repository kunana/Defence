﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartSceneManager : MonoBehaviour {

    
    private StartSceneManager _instance = null;
    public StartSceneManager instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new StartSceneManager();
            }
            return _instance;
        }
    }
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    private void StartGame()
    {
        SceneManager.LoadScene("Game");
    }
    private void SettingBtn()
    {
        if (settingbtn !=null)
        {

        }
    }
    private void OnMouseDown()
    {
        StartGame();
    }
}
